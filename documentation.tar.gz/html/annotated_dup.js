var annotated_dup =
[
    [ "Node", "d8/d49/structNode.html", "d8/d49/structNode" ],
    [ "request", "dc/d20/structrequest.html", "dc/d20/structrequest" ],
    [ "Saurion", "d5/da0/classSaurion.html", "d5/da0/classSaurion" ],
    [ "saurion", "df/d32/structsaurion.html", "df/d32/structsaurion" ],
    [ "saurion_callbacks", "d8/d5e/structsaurion__callbacks.html", "d8/d5e/structsaurion__callbacks" ],
    [ "saurion_wrapper", "df/df5/structsaurion__wrapper.html", "df/df5/structsaurion__wrapper" ],
    [ "Task", "d1/de8/structTask.html", "d1/de8/structTask" ],
    [ "ThreadPool", "dc/de7/classThreadPool.html", "dc/de7/classThreadPool" ]
];