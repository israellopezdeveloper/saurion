var structTask =
[
    [ "Task", "d1/de8/structTask.html#a3dbf292367317f66f00d90d5a6db7feb", null ],
    [ "Task", "d1/de8/structTask.html#a6f23dc08d0742b7d482313301b485dfe", null ],
    [ "Task", "d1/de8/structTask.html#ae146c98551f244f62b93bc7b4e334580", null ],
    [ "~Task", "d1/de8/structTask.html#aa96ed750d563ddff7389afcb9ae5d0be", null ],
    [ "operator=", "d1/de8/structTask.html#a28266635b1b105e481d703eaffb15666", null ],
    [ "operator=", "d1/de8/structTask.html#a9ea72b7f2d21107b03c5b55f250fd511", null ],
    [ "argument", "d1/de8/structTask.html#ae8fb524e61bb27a40a337fd5ac3c623e", null ],
    [ "function", "d1/de8/structTask.html#adc420632142dc624b207d1b6bbec8c6c", null ]
];