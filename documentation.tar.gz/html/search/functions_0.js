var searchData=
[
  ['add_0',['add',['../dc/de7/classThreadPool.html#a96cabae5dcc0358c6df3e303cf369456',1,'ThreadPool::add(uint32_t qid, void(*nfn)(void *), void *arg)'],['../dc/de7/classThreadPool.html#a98fa999bd2f502ff445a3d5b3e96e808',1,'ThreadPool::add(void(*nfn)(void *), void *arg)']]],
  ['add_5faccept_1',['add_accept',['../de/d27/low__saurion_8c.html#a40aa700cf97b0ad654fe0aff06644ae9',1,'low_saurion.c']]],
  ['add_5fefd_2',['add_efd',['../de/d27/low__saurion_8c.html#a2794e5aada66af40962e04b938bbd88a',1,'low_saurion.c']]],
  ['add_5fread_3',['add_read',['../de/d27/low__saurion_8c.html#a2299a2be116729fdb774a5e655ff9f83',1,'low_saurion.c']]],
  ['add_5fread_5fcontinue_4',['add_read_continue',['../de/d27/low__saurion_8c.html#ab40f6349969e5ce57e654ddb9eaf827a',1,'low_saurion.c']]],
  ['add_5fwrite_5',['add_write',['../de/d27/low__saurion_8c.html#a39042ff39576b4db8db514acd6e9a224',1,'low_saurion.c']]],
  ['allocate_5fiovec_6',['allocate_iovec',['../d9/da3/group__LowSaurion.html#ga1c329b9155a9159b696b60247c9b328b',1,'allocate_iovec(struct iovec *iov, size_t amount, size_t pos, size_t size, void **chd_ptr):&#160;low_saurion.c'],['../d9/da3/group__LowSaurion.html#ga1c329b9155a9159b696b60247c9b328b',1,'allocate_iovec(struct iovec *iov, size_t amount, size_t pos, size_t size, void **chd_ptr):&#160;low_saurion.c']]],
  ['asyncmultiqueue_7',['AsyncMultiQueue',['../d6/d2f/structThreadPool_1_1AsyncMultiQueue.html#ac074507a64932a17709c5c44a91a4d16',1,'ThreadPool::AsyncMultiQueue::AsyncMultiQueue()'],['../d6/d2f/structThreadPool_1_1AsyncMultiQueue.html#a910aba2e46df045b912eacab8521d092',1,'ThreadPool::AsyncMultiQueue::AsyncMultiQueue(const AsyncMultiQueue &amp;)=delete'],['../d6/d2f/structThreadPool_1_1AsyncMultiQueue.html#aa9d6e2938cfadd6af41a6bc2a5ac28fb',1,'ThreadPool::AsyncMultiQueue::AsyncMultiQueue(AsyncMultiQueue &amp;&amp;)=delete']]],
  ['asyncqueue_8',['AsyncQueue',['../d8/dd6/structThreadPool_1_1AsyncQueue.html#aa26d62e8948391895058149d5300fec1',1,'ThreadPool::AsyncQueue::AsyncQueue(uint32_t cnt)'],['../d8/dd6/structThreadPool_1_1AsyncQueue.html#a206e10b39c26a3f7c435dbfb74bf50e1',1,'ThreadPool::AsyncQueue::AsyncQueue(const AsyncQueue &amp;)=delete'],['../d8/dd6/structThreadPool_1_1AsyncQueue.html#ac4412663b25de78fc191e8dad5213273',1,'ThreadPool::AsyncQueue::AsyncQueue(AsyncQueue &amp;&amp;)=delete']]]
];
