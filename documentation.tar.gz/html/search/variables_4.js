var searchData=
[
  ['iov_0',['iov',['../dc/d20/structrequest.html#ae23ac64f6ae30671afc753260ef411fd',1,'request']]],
  ['iovec_5fcount_1',['iovec_count',['../dc/d20/structrequest.html#a1291bf32fbcafa3bb4b348578db09a9f',1,'request']]]
];
