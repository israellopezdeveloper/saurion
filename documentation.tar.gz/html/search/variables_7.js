var searchData=
[
  ['n_5fthreads_0',['n_threads',['../df/d32/structsaurion.html#aee308efd9e70f3b38da24483a3f74413',1,'saurion::n_threads'],['../d3/d68/low__saurion_8h.html#a7001c0d6b3bf1fa114a0d230c6190e3d',1,'n_threads:&#160;low_saurion.h']]],
  ['next_1',['next',['../d8/d49/structNode.html#af67b110ca1a258b793bf69d306929b22',1,'Node::next'],['../df/d32/structsaurion.html#a2742eddc30d4e4409b9f1a98cf7eb054',1,'saurion::next'],['../d3/d68/low__saurion_8h.html#a9b4556b86497af3cd53528515556b0f3',1,'next:&#160;low_saurion.h']]],
  ['next_5fiov_2',['next_iov',['../dc/d20/structrequest.html#a4aba582d3fcf1110aa8f272d5b038a3d',1,'request']]],
  ['next_5foffset_3',['next_offset',['../dc/d20/structrequest.html#a03abde14b48986b40d827b22e4ddfb2d',1,'request']]]
];
