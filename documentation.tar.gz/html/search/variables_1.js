var searchData=
[
  ['children_0',['children',['../d8/d49/structNode.html#a3d857c2fdb25634fe92ca32ff006c233',1,'Node']]],
  ['client_5fsocket_1',['client_socket',['../dc/d20/structrequest.html#a34dcdf74ea1d647ba95bcdd78c95c3b7',1,'request']]]
];
