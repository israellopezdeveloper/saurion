var searchData=
[
  ['max_0',['MAX',['../de/d27/low__saurion_8c.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f',1,'low_saurion.c']]],
  ['min_1',['MIN',['../de/d27/low__saurion_8c.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'low_saurion.c']]]
];
