var searchData=
[
  ['event_5ftype_5faccept_0',['EVENT_TYPE_ACCEPT',['../de/d27/low__saurion_8c.html#a96a7a2db32d44325af7e4db5fe599675',1,'low_saurion.c']]],
  ['event_5ftype_5ferror_1',['EVENT_TYPE_ERROR',['../de/d27/low__saurion_8c.html#a7a838ec11db7afb74af46c55e0cb6e43',1,'low_saurion.c']]],
  ['event_5ftype_5fread_2',['EVENT_TYPE_READ',['../de/d27/low__saurion_8c.html#a1f7c29ac665cde9aa26808bb269837d9',1,'low_saurion.c']]],
  ['event_5ftype_5fwait_3',['EVENT_TYPE_WAIT',['../de/d27/low__saurion_8c.html#a59fc72da421a569911ec34c1c0537e9d',1,'low_saurion.c']]],
  ['event_5ftype_5fwrite_4',['EVENT_TYPE_WRITE',['../de/d27/low__saurion_8c.html#a387dc1b3761c4fd9e9b40030bc5b78c8',1,'low_saurion.c']]]
];
