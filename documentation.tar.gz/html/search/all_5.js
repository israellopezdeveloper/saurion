var searchData=
[
  ['init_0',['init',['../d5/da0/classSaurion.html#ad5408d5b521e109da8c5c32b134c1fb4',1,'Saurion::init()'],['../dc/de7/classThreadPool.html#a53b794c6101360ebfe6a8d903ba73298',1,'ThreadPool::init()']]],
  ['initialize_5fiovec_1',['initialize_iovec',['../d9/da3/group__LowSaurion.html#gae64e81c0ce5f52d51684d8f1129e6076',1,'initialize_iovec(struct iovec *iov, size_t amount, size_t pos, const void *msg, size_t size, uint8_t h):&#160;low_saurion.c'],['../d9/da3/group__LowSaurion.html#gae64e81c0ce5f52d51684d8f1129e6076',1,'initialize_iovec(struct iovec *iov, size_t amount, size_t pos, const void *msg, size_t size, uint8_t h):&#160;low_saurion.c']]],
  ['iov_2',['iov',['../dc/d20/structrequest.html#ae23ac64f6ae30671afc753260ef411fd',1,'request']]],
  ['iovec_5fcount_3',['iovec_count',['../dc/d20/structrequest.html#a1291bf32fbcafa3bb4b348578db09a9f',1,'request']]]
];
