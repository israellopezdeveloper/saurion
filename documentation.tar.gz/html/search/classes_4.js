var searchData=
[
  ['task_0',['Task',['../d1/de8/structTask.html',1,'']]],
  ['threadpool_1',['ThreadPool',['../dc/de7/classThreadPool.html',1,'']]]
];
