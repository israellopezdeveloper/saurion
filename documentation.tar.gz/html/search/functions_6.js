var searchData=
[
  ['list_5fdelete_5fnode_0',['list_delete_node',['../d3/d32/linked__list_8c.html#aa32b1822e1be57484b2244e42f1d75ac',1,'list_delete_node(struct Node **head, void *ptr):&#160;linked_list.c'],['../d1/d4a/linked__list_8h.html#aa32b1822e1be57484b2244e42f1d75ac',1,'list_delete_node(struct Node **head, void *ptr):&#160;linked_list.c']]],
  ['list_5ffree_1',['list_free',['../d3/d32/linked__list_8c.html#ac33c30e895caddc11181b50eca0ab735',1,'list_free(struct Node **head):&#160;linked_list.c'],['../d1/d4a/linked__list_8h.html#ac33c30e895caddc11181b50eca0ab735',1,'list_free(struct Node **head):&#160;linked_list.c']]],
  ['list_5finsert_2',['list_insert',['../d3/d32/linked__list_8c.html#aee07283e23385804a1d3f880cd99731e',1,'list_insert(struct Node **head, void *ptr, size_t amount, void **children):&#160;linked_list.c'],['../d1/d4a/linked__list_8h.html#aee07283e23385804a1d3f880cd99731e',1,'list_insert(struct Node **head, void *ptr, size_t amount, void **children):&#160;linked_list.c']]]
];
