var searchData=
[
  ['efds_0',['efds',['../df/d32/structsaurion.html#a08e1b7aa083a0d311658ff7072ae7a46',1,'saurion::efds'],['../d3/d68/low__saurion_8h.html#a605489576f3bb0a77d1492cd83539001',1,'efds:&#160;low_saurion.h']]],
  ['event_5ftype_1',['event_type',['../dc/d20/structrequest.html#a9cba15f1748716ffe6869a271c1ccc4d',1,'request']]]
];
