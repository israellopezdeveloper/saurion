var searchData=
[
  ['argument_0',['argument',['../d1/de8/structTask.html#ae8fb524e61bb27a40a337fd5ac3c623e',1,'Task']]]
];
