var structsaurion_1_1saurion__callbacks =
[
    [ "on_closed", "d9/d62/structsaurion_1_1saurion__callbacks.html#a330a80c99984cb4412f87522ac040e6a", null ],
    [ "on_closed_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#adbb1d46a589abef434e23191766891fe", null ],
    [ "on_connected", "d9/d62/structsaurion_1_1saurion__callbacks.html#abbcac9a2cf6dccbf698fd56f4b672d80", null ],
    [ "on_connected_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#a1680ee7a4bc10737a8ca95c1e003e786", null ],
    [ "on_error", "d9/d62/structsaurion_1_1saurion__callbacks.html#a4bb8e66fb0b5b7d204e4b43828b37d67", null ],
    [ "on_error_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#a72891fef0ba0293233f008aae9ede7aa", null ],
    [ "on_readed", "d9/d62/structsaurion_1_1saurion__callbacks.html#ae67cde94f799274a710213af64ed5e58", null ],
    [ "on_readed_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#a02270cf60b25c999a180fcb9381b53d0", null ],
    [ "on_wrote", "d9/d62/structsaurion_1_1saurion__callbacks.html#a49664c1b74e1c71b4703a232c3ccc2c7", null ],
    [ "on_wrote_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#a148b0aae663aafb51fbcf17286d66369", null ]
];