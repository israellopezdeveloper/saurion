var group__LowSaurion =
[
    [ "saurion", "df/d32/structsaurion.html", [
      [ "saurion_callbacks", "d9/d62/structsaurion_1_1saurion__callbacks.html", [
        [ "on_closed", "d9/d62/structsaurion_1_1saurion__callbacks.html#a330a80c99984cb4412f87522ac040e6a", null ],
        [ "on_closed_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#adbb1d46a589abef434e23191766891fe", null ],
        [ "on_connected", "d9/d62/structsaurion_1_1saurion__callbacks.html#abbcac9a2cf6dccbf698fd56f4b672d80", null ],
        [ "on_connected_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#a1680ee7a4bc10737a8ca95c1e003e786", null ],
        [ "on_error", "d9/d62/structsaurion_1_1saurion__callbacks.html#a4bb8e66fb0b5b7d204e4b43828b37d67", null ],
        [ "on_error_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#a72891fef0ba0293233f008aae9ede7aa", null ],
        [ "on_readed", "d9/d62/structsaurion_1_1saurion__callbacks.html#ae67cde94f799274a710213af64ed5e58", null ],
        [ "on_readed_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#a02270cf60b25c999a180fcb9381b53d0", null ],
        [ "on_wrote", "d9/d62/structsaurion_1_1saurion__callbacks.html#a49664c1b74e1c71b4703a232c3ccc2c7", null ],
        [ "on_wrote_arg", "d9/d62/structsaurion_1_1saurion__callbacks.html#a148b0aae663aafb51fbcf17286d66369", null ]
      ] ],
      [ "efds", "df/d32/structsaurion.html#a08e1b7aa083a0d311658ff7072ae7a46", null ],
      [ "list", "df/d32/structsaurion.html#a63c38a9dc703180b628935d72236318f", null ],
      [ "m_rings", "df/d32/structsaurion.html#ad3305571e32bbb72bc95caefbb68b030", null ],
      [ "n_threads", "df/d32/structsaurion.html#aee308efd9e70f3b38da24483a3f74413", null ],
      [ "next", "df/d32/structsaurion.html#a2742eddc30d4e4409b9f1a98cf7eb054", null ],
      [ "pool", "df/d32/structsaurion.html#aa6d22bb06ad66a5a860fcd642b4e7905", null ],
      [ "rings", "df/d32/structsaurion.html#a4858f070287e6269298089b993793830", null ],
      [ "ss", "df/d32/structsaurion.html#ae85c8eed456efd00dcc93d005b0ad99c", null ],
      [ "status", "df/d32/structsaurion.html#a342abf92b861ebc82e50349fe31246e2", null ],
      [ "status_c", "df/d32/structsaurion.html#add5f25d5f709bda89fa5461eecdc2b2e", null ],
      [ "status_m", "df/d32/structsaurion.html#ad05334ffef73d89577b3bc60ecc11283", null ]
    ] ],
    [ "PACKING_SZ", "d9/da3/group__LowSaurion.html#ga7889939b2b6cdf65275305251f749af0", null ],
    [ "allocate_iovec", "d9/da3/group__LowSaurion.html#ga1c329b9155a9159b696b60247c9b328b", null ],
    [ "EXTERNAL_set_socket", "d9/da3/group__LowSaurion.html#ga4a0bc8233ca030e29b9b94aed0177392", null ],
    [ "free_request", "d9/da3/group__LowSaurion.html#ga0f9760bc800b946244ccf790081e6bb3", null ],
    [ "initialize_iovec", "d9/da3/group__LowSaurion.html#gae64e81c0ce5f52d51684d8f1129e6076", null ],
    [ "read_chunk", "d9/da3/group__LowSaurion.html#gaec24df6ee2f4999bf64acf5fc42ed019", null ],
    [ "saurion_create", "d9/da3/group__LowSaurion.html#gae589ab08ed623ad2ab6d13beec33b131", null ],
    [ "saurion_destroy", "d9/da3/group__LowSaurion.html#ga7893ccf90a98845d5d95ffda0260d0b8", null ],
    [ "saurion_send", "d9/da3/group__LowSaurion.html#gadd63cf225e55bcf4cd22ddcbd9d1c9b7", null ],
    [ "saurion_start", "d9/da3/group__LowSaurion.html#gaeeab8302b41112175566881a1b7bf905", null ],
    [ "saurion_stop", "d9/da3/group__LowSaurion.html#ga9f32b41ec23178c2a693fec057b96532", null ],
    [ "set_request", "d9/da3/group__LowSaurion.html#gaddb696f3c38e160dde5a5de6e6e10f70", null ]
];