var low__saurion__secret_8h =
[
    [ "allocate_iovec", "d9/da3/group__LowSaurion.html#ga1c329b9155a9159b696b60247c9b328b", null ],
    [ "free_request", "d9/da3/group__LowSaurion.html#ga0f9760bc800b946244ccf790081e6bb3", null ],
    [ "initialize_iovec", "d9/da3/group__LowSaurion.html#gae64e81c0ce5f52d51684d8f1129e6076", null ],
    [ "read_chunk", "d9/da3/group__LowSaurion.html#gaec24df6ee2f4999bf64acf5fc42ed019", null ],
    [ "set_request", "d9/da3/group__LowSaurion.html#gaddb696f3c38e160dde5a5de6e6e10f70", null ]
];