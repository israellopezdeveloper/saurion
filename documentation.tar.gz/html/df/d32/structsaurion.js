var structsaurion =
[
    [ "saurion_callbacks", "d9/d62/structsaurion_1_1saurion__callbacks.html", "d9/d62/structsaurion_1_1saurion__callbacks" ],
    [ "efds", "df/d32/structsaurion.html#a08e1b7aa083a0d311658ff7072ae7a46", null ],
    [ "list", "df/d32/structsaurion.html#a63c38a9dc703180b628935d72236318f", null ],
    [ "m_rings", "df/d32/structsaurion.html#ad3305571e32bbb72bc95caefbb68b030", null ],
    [ "n_threads", "df/d32/structsaurion.html#aee308efd9e70f3b38da24483a3f74413", null ],
    [ "next", "df/d32/structsaurion.html#a2742eddc30d4e4409b9f1a98cf7eb054", null ],
    [ "pool", "df/d32/structsaurion.html#aa6d22bb06ad66a5a860fcd642b4e7905", null ],
    [ "rings", "df/d32/structsaurion.html#a4858f070287e6269298089b993793830", null ],
    [ "ss", "df/d32/structsaurion.html#ae85c8eed456efd00dcc93d005b0ad99c", null ],
    [ "status", "df/d32/structsaurion.html#a342abf92b861ebc82e50349fe31246e2", null ],
    [ "status_c", "df/d32/structsaurion.html#add5f25d5f709bda89fa5461eecdc2b2e", null ],
    [ "status_m", "df/d32/structsaurion.html#ad05334ffef73d89577b3bc60ecc11283", null ]
];