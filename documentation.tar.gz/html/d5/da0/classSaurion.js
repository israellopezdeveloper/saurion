var classSaurion =
[
    [ "ClosedCb", "d5/da0/classSaurion.html#a2c2ca67aafeb00369c86f62c94614225", null ],
    [ "ConnectedCb", "d5/da0/classSaurion.html#a1a4646725512c48c9bc44af91fc826eb", null ],
    [ "ErrorCb", "d5/da0/classSaurion.html#af58c5aaaa5171a6b71c9e62c34db5fce", null ],
    [ "ReadedCb", "d5/da0/classSaurion.html#a2cacb6e2775688b834247cf95bab0518", null ],
    [ "WroteCb", "d5/da0/classSaurion.html#a20f08b0f185563100d81c19355cc1b47", null ],
    [ "Saurion", "d5/da0/classSaurion.html#a56b8393a788078d51ad08792ccdcd713", null ],
    [ "~Saurion", "d5/da0/classSaurion.html#a3ea35eafe420d514b0147d69c745e7df", null ],
    [ "Saurion", "d5/da0/classSaurion.html#ae83d691a9d4a9c9d55ed7678b0608385", null ],
    [ "Saurion", "d5/da0/classSaurion.html#a2bda2b93047d6a70c3510bc4c84e151f", null ],
    [ "init", "d5/da0/classSaurion.html#ad5408d5b521e109da8c5c32b134c1fb4", null ],
    [ "on_closed", "d5/da0/classSaurion.html#a0ad01e1c10b794fd10e5be17e9b5c4dd", null ],
    [ "on_connected", "d5/da0/classSaurion.html#af1563e363c5a007289e6aa3a4d59860e", null ],
    [ "on_error", "d5/da0/classSaurion.html#a6a2ce2d5d7d62c110702c51b73a56a8d", null ],
    [ "on_readed", "d5/da0/classSaurion.html#a4739a8d5e3b2ae2618ea602c7d9e046b", null ],
    [ "on_wrote", "d5/da0/classSaurion.html#a8450efc4ac6a6da43b3bad0d2f8a9b34", null ],
    [ "operator=", "d5/da0/classSaurion.html#a737974c4ed549a52a73ae6e3545a8ba0", null ],
    [ "operator=", "d5/da0/classSaurion.html#a315dcaed2d3675c068d9fcd0c723001c", null ],
    [ "send", "d5/da0/classSaurion.html#af652625283a9752d16d7a24b35cec14d", null ],
    [ "stop", "d5/da0/classSaurion.html#aeb75b8b41463e2a5b10ca446f36ebe00", null ],
    [ "s", "d5/da0/classSaurion.html#a6f75f768b084ef03214b178d3746f142", null ]
];