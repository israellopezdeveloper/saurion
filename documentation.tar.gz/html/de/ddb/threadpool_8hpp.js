var threadpool_8hpp =
[
    [ "Task", "d1/de8/structTask.html", "d1/de8/structTask" ],
    [ "ThreadPool", "dc/de7/classThreadPool.html", "dc/de7/classThreadPool" ],
    [ "ThreadPool::AsyncQueue", "d8/dd6/structThreadPool_1_1AsyncQueue.html", "d8/dd6/structThreadPool_1_1AsyncQueue" ],
    [ "ThreadPool::AsyncMultiQueue", "d6/d2f/structThreadPool_1_1AsyncMultiQueue.html", "d6/d2f/structThreadPool_1_1AsyncMultiQueue" ],
    [ "StopFlags", "de/ddb/threadpool_8hpp.html#a563f3adc3406990c650e8cc2efdc63d6", [
      [ "KINDLY", "de/ddb/threadpool_8hpp.html#a563f3adc3406990c650e8cc2efdc63d6ac09d7c5a2161fc65c10f96ed5a46dc30", null ],
      [ "FORCE", "de/ddb/threadpool_8hpp.html#a563f3adc3406990c650e8cc2efdc63d6a2a4d3752e9aa5f28fc2dacb0f948de06", null ]
    ] ]
];