var structrequest =
[
    [ "client_socket", "dc/d20/structrequest.html#a34dcdf74ea1d647ba95bcdd78c95c3b7", null ],
    [ "event_type", "dc/d20/structrequest.html#a9cba15f1748716ffe6869a271c1ccc4d", null ],
    [ "iov", "dc/d20/structrequest.html#ae23ac64f6ae30671afc753260ef411fd", null ],
    [ "iovec_count", "dc/d20/structrequest.html#a1291bf32fbcafa3bb4b348578db09a9f", null ],
    [ "next_iov", "dc/d20/structrequest.html#a4aba582d3fcf1110aa8f272d5b038a3d", null ],
    [ "next_offset", "dc/d20/structrequest.html#a03abde14b48986b40d827b22e4ddfb2d", null ],
    [ "prev", "dc/d20/structrequest.html#ab8f409ae411cecc817a691455830f700", null ],
    [ "prev_remain", "dc/d20/structrequest.html#acb69c014fb67502b59cd112d3758569f", null ],
    [ "prev_size", "dc/d20/structrequest.html#a02dc8e759c5216e1b7f7c908a0e0481f", null ]
];