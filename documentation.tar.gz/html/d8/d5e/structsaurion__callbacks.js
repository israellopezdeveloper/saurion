var structsaurion__callbacks =
[
    [ "on_closed", "d8/d5e/structsaurion__callbacks.html#a92d10ed4a5e24fe94067f2fa3f8115e4", null ],
    [ "on_closed_arg", "d8/d5e/structsaurion__callbacks.html#a0c6906d4a2fcd277ce1b3703e20f41d2", null ],
    [ "on_connected", "d8/d5e/structsaurion__callbacks.html#aadebdbd46d651eafc8ff2cb5492dd337", null ],
    [ "on_connected_arg", "d8/d5e/structsaurion__callbacks.html#a0448514287c7c368cddcecd51b44ab0e", null ],
    [ "on_error", "d8/d5e/structsaurion__callbacks.html#a4d99e1bab4869f6c0b47d3e630c0a2f1", null ],
    [ "on_error_arg", "d8/d5e/structsaurion__callbacks.html#ad3372ecd9a17439b84edf72bb9377089", null ],
    [ "on_readed", "d8/d5e/structsaurion__callbacks.html#a15c5a8dc04e2c4083502eb9f7f2c7997", null ],
    [ "on_readed_arg", "d8/d5e/structsaurion__callbacks.html#a46d60adf1f70df83058296234572c978", null ],
    [ "on_wrote", "d8/d5e/structsaurion__callbacks.html#a19b5d0802302a7120a3ad718ebb8cb2a", null ],
    [ "on_wrote_arg", "d8/d5e/structsaurion__callbacks.html#a534ea394c43e9b450e8679d5c8f8d0bd", null ]
];