var structNode =
[
    [ "children", "d8/d49/structNode.html#a3d857c2fdb25634fe92ca32ff006c233", null ],
    [ "next", "d8/d49/structNode.html#af67b110ca1a258b793bf69d306929b22", null ],
    [ "ptr", "d8/d49/structNode.html#a174a6b1ed6b6b34a9a313ae1d686f9ee", null ],
    [ "size", "d8/d49/structNode.html#aeda96509e2e7bbcbb3c35c498b4f7d3a", null ]
];